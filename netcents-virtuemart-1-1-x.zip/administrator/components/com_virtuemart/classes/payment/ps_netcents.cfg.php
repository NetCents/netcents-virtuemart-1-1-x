<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('NETCENTS_API_KEY', '');
define ('NETCENTS_SECRET_KEY', '');
define ('NETCENTS_GATEWAY', 'https://merchant.net-cents.com');
define ('NETCENTS_HOSTED_PAYMENT_ID', '');
