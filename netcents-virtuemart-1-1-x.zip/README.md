View installation guide: 

https://merchant-support.net-cents.com/knowledge/virtuemart-1.1.x