How to install:

Upload the files to the appropriate directories. The directory structure is consistent with that of your VirtueMart installation.

For example upload ps_netcents.php and ps_netcents.cfg.php to

/administrator/components/com_virtuemart/classes/payment/

Do the same for any files within directories.
Add them to the appropriate directory on your server.