<?php 
$_REQUEST['option'] = "com_virtuemart";
$_REQUEST['page'] = "checkout.2Checkout_result";
$_REQUEST['Itemid'] = 1;
require_once("index.php");
?>
